'use strict';

module.exports = require('./lib/mean-seo');