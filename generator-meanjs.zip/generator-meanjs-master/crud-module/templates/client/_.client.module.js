(function (app) {
  'use strict';

  app.registerModule('<%= slugifiedPluralName %>');
})(ApplicationConfiguration);
