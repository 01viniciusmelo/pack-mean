'use strict';

angular.module('<%= slugifiedModuleName %>').controller('<%= classifiedControllerName %>Controller', ['$scope',
  function ($scope) {
    // <%= humanizedControllerName %> controller logic
    // ...
  }
]);
