'use strict';

/**
 * Module dependencies.
 */
var path = require('path'),
  mongoose = require('mongoose'),
  errorHandler = require(path.resolve('./modules/core/server/controllers/errors.server.controller')),
  _ = require('lodash');

/**
 * Create a <%= humanizedSingularName %>
 */
exports.create = function (req, res) {

};

/**
 * Show the current <%= humanizedSingularName %>
 */
exports.read = function (req, res) {

};

/**
 * Update a <%= humanizedSingularName %>
 */
exports.update = function (req, res) {

};

/**
 * Delete an <%= humanizedSingularName %>
 */
exports.delete = function (req, res) {

};

/**
 * List of <%= humanizedPluralName %>
 */
exports.list = function (req, res) {

};
