(function (app) {
  'use strict';

  app.registerModule('<%= slugifiedName %>');
})(ApplicationConfiguration);
